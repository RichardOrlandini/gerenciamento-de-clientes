INSERT INTO clientes (nome, email, telefone, x, y) VALUES
('Cliente 1', 'cliente1@example.com', '123456789', 10, 20),
('Cliente 2', 'cliente2@example.com', '987654321', 20, 30),
('Cliente 3', 'cliente3@example.com', '123123123', 30, 40);
