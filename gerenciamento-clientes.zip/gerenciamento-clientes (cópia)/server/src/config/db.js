const { Pool } = require('pg');

const pool = new Pool({
  user: 'rich',
  host: 'localhost',
  database: 'postgresql',
  password: '123',
  port: 5434,
});

module.exports = pool;
