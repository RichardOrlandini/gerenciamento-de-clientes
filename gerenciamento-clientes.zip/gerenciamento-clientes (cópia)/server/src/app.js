const express = require('express');
const migrateDatabase = require('./migrate'); // Ajuste o caminho conforme necessário
const clienteRoutes = require('./routes/clienteRoutes'); // Supondo que o nome do arquivo seja clienteController.js
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());


app.use('/clientes', clienteRoutes);
  
const startServer = async () => {
  try {
    await migrateDatabase(); 
    const PORT = process.env.PORT || 3001;
    app.listen(PORT, () => {
      console.log(`Servidor rodando na porta ${PORT}`);
    });
  } catch (error) {
    console.error("Não foi possível iniciar o servidor devido a um erro de migração:", error);
  }
};

startServer();
