const pool = require('../config/db');

exports.getAllClientes = async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM clientes');
    res.status(200).json(rows);
};

exports.createCliente = async (req, res) => {
    const { nome, email, telefone, x, y } = req.body;
    const { rows } = await pool.query(
        'INSERT INTO clientes (nome, email, telefone, x, y) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [nome, email, telefone, x, y]
    );
    res.status(201).json(rows[0]);
};

exports.calculateRote = async (req, res) => {
    const { rows: clientes } = await pool.query('SELECT * FROM clientes');
    let rota = calculateRouteNeighbor(clientes);
    res.status(200).json(rota);
};


// Calcula a distância euclidiana entre a posição atual e a posição do cliente
// Utiliza o Teorema de Pitágoras para encontrar a "distância em linha reta"
function calculateRouteNeighbor(clientes) {
    let rota = [], xAtual = 0, yAtual = 0;
    let distanciaMinima, indiceProximoCliente;

    while (clientes.length > 0) {
        distanciaMinima = Infinity;

        for (let i = 0; i < clientes.length; i++) {
            let dist = Math.sqrt((clientes[i].x - xAtual) ** 2 + (clientes[i].y - yAtual) ** 2);
            if (dist < distanciaMinima) {
                distanciaMinima = dist;
                indiceProximoCliente = i;
            }
        }

        let proximoCliente = clientes.splice(indiceProximoCliente, 1)[0];
        rota.push(proximoCliente);
        xAtual = proximoCliente.x;
        yAtual = proximoCliente.y;
    }

    // Adiciona o retorno ao ponto de origem se necessário
    // rota.push({ x: 0, y: 0 });

    return rota;
}

