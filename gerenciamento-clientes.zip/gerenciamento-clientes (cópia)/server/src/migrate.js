const fs = require('fs');
const path = require('path');
const pool = require('./config/db');

// Removendo a chamada para pool.end() para evitar fechamento prematuro
const migrateDatabase = async () => {
  try {
    const migrationsDir = path.join(__dirname, '..', 'migrations');
    const migrationFiles = fs.readdirSync(migrationsDir).sort();

    for (const file of migrationFiles) {
      if (path.extname(file) === '.sql') {
        const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
        await pool.query(sql);
        console.log(`Migração aplicada: ${file}`);
      }
    }
  } catch (error) {
    console.error('Erro ao aplicar migração:', error);
    throw error; // Lança o erro para ser tratado onde a função é chamada
  }
};

migrateDatabase();

module.exports = migrateDatabase;
