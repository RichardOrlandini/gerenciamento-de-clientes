import './App.css';
import React, { useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import { Container, Modal, Typography, List, ListItem, ListItemText, TablePagination, Box } from '@mui/material';

function App() {
  const [filtroNome, setFiltroNome] = useState('');
  const [clientes, setClientes] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [x, setX] = useState('');
  const [y, setY] = useState('');

  const [modalOpen, setModalOpen] = useState(false);
  const [rotaCalculada, setRotaCalculada] = useState([]);


  useEffect(() => {
    carregarClientes();
  }, []);

  const carregarClientes = async () => {
    const resposta = await fetch('http://localhost:3001/clientes');
    const data = await resposta.json();
    setClientes(data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Implementar a lógica para adicionar um cliente
    const cliente = { nome, email, telefone, x, y };
    await fetch('http://localhost:3001/clientes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(cliente),
    });

    setNome('');
    setEmail('');
    setTelefone('');
    setX('');
    setY('');
    carregarClientes();
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); // Volta para a primeira página com o novo número de itens por página
  };

  const buscarRota = async () => {
    const resposta = await fetch('http://localhost:3001/clientes/calcular-rota');
    const rota = await resposta.json();
    setRotaCalculada(rota);
    setModalOpen(true);
  };

  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
  };


  return (
    <Container maxWidth="md" sx={{ marginLeft: 5, marginTop: 2 }}>
      <Typography variant="h4" gutterBottom>Sistema de Gerenciamento de Clientes</Typography>

      <TextField
        fullWidth
        label="Pesquisar Cliente"
        value={filtroNome}
        onChange={(e) => setFiltroNome(e.target.value)}
        margin="normal"
      />

      <List>
        {clientes
          .filter((cliente) =>
            cliente.nome.toLowerCase().includes(filtroNome.toLowerCase())
          )
          .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
          .map((cliente) => (
            <ListItem key={cliente.id}>
              <ListItemText
                primary={cliente.nome}
                secondary={`Email: ${cliente.email}, Telefone: ${cliente.telefone}, Coordenadas: (${cliente.x}, ${cliente.y})`}
              />
            </ListItem>
          ))}
      </List>
      <Box display="flex" justifyContent="center" alignItems="center">
        <TablePagination
          component="div"
          count={clientes.filter((cliente) =>
            cliente.nome.toLowerCase().includes(filtroNome.toLowerCase())
          ).length}
          page={page}
          onPageChange={handleChangePage}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Box>

      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField
              required
              fullWidth
              label="Nome"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              required
              fullWidth
              label="Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              required
              fullWidth
              type='tel'
              label="Telefone"
              value={telefone}
              onChange={(e) => setTelefone(e.target.value)}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              required
              type='number'
              fullWidth
              label="Coordenada X"
              value={x}
              onChange={(e) => setX(e.target.value)}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              required
              type='number'
              fullWidth
              label="Coordenada Y"
              value={y}
              onChange={(e) => setY(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <Button type="submit" variant="contained" color="primary">
              Adicionar Cliente
            </Button>
          </Grid>
        </Grid>
      </form>


      <Button variant="contained" onClick={buscarRota}>Calcular Rota</Button>
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Rota de Atendimento
          </Typography>
          <List id="modal-modal-description">
            {rotaCalculada.map((cliente, index) => (
              <ListItem key={index}>
                <ListItemText primary={cliente.nome} secondary={`Coordenadas: (${cliente.x}, ${cliente.y})`} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Modal>


    </Container>
  );
}

export default App;
